import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js'; // Adjust path if needed

// ==============================
// 🚪 Login Controller
// ==============================
export const login = async (req, res) => {
  const { email, password } = req.body;
  const emailLower = email?.toLowerCase();
  console.log("🔑 Login request body:", req.body);

  try {
    const user = await User.findOne({ email: emailLower });

    if (!user) {
      console.log("❌ User not found");
      return res.status(400).json({ message: "User not found" });
    }

    console.log("👉 Entered password:", password);
    console.log("🔐 Stored hash in DB:", user.password);

    const isMatch = await bcrypt.compare(password, user.password);
    console.log("✅ Password match result:", isMatch);

    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Optionally, generate JWT token
    // const token = jwt.sign({ id: user._id }, "your_jwt_secret", { expiresIn: "1h" });

    return res.status(200).json({ message: "Login successful" /* , token */ });

  } catch (err) {
    console.error("🔥 Login error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};

// ==============================
// 📝 Signup Controller
// ==============================
export const signup = async (req, res) => {
  const { username, email, password } = req.body || {};
  const emailLower = email?.toLowerCase();
  console.log("📝 Signup request body:", req.body);

  if (!username || !email || !password) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const existingUser = await User.findOne({ email: emailLower });
    if (existingUser) {
      console.log("⚠️ User already exists");
      return res.status(400).json({ message: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("🔐 Hashed password to be saved:", hashedPassword);

    const newUser = new User({
      username,
      email: emailLower,
      password: hashedPassword
    });

    await newUser.save();

    return res.status(201).json({ message: 'User created successfully' });

  } catch (err) {
    console.error("🔥 Signup error:", err);
    return res.status(500).json({ message: 'Server error', error: err.message });
  }
};
