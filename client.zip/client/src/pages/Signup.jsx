export default function Signup() {
    return <h1>📝 Signup Page</h1>;
  }
  