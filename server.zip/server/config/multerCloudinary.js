// server/config/multerCloudinary.js
import multer from 'multer';
import multerStorageCloudinary from 'multer-storage-cloudinary';
import cloudinary from './cloudinary.js'; // Import Cloudinary config

const storage = multerStorageCloudinary({
  cloudinary,
  folder: 'superhero_avatars',  // Folder in Cloudinary where images will be stored
  allowedFormats: ['jpg', 'jpeg', 'png'],  // Allow these formats
});

const upload = multer({ storage });

export default upload;
