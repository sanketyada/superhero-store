import express from 'express';
import { login, signup } from '../controllers/authController.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/signup', signup);
router.post('/login', login);

// 🛡️ Protected route
router.get('/profile', authMiddleware, (req, res) => {
  res.json({
    message: 'Welcome to your profile!',
    user: req.user, // contains decoded token info like id, email, etc.
  });
});

export default router;
