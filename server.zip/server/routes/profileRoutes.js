import express from 'express';
import multer from 'multer';
import path from 'path';
import { updateAvatar } from '../controllers/profileController.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

// Setup Multer for image upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); // make sure this folder exists
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // e.g., 1710000000.jpg
  },
});
const upload = multer({ storage });

// Protected route to update profile avatar
router.put('/avatar', authMiddleware, upload.single('avatar'), updateAvatar);

export default router;
