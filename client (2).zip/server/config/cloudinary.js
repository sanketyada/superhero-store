// server/config/cloudinary.js
import cloudinary from 'cloudinary';

cloudinary.config({
  cloud_name: 'dxptmoqve',  // Replace with your Cloudinary cloud name
  api_key: '964615593112113',        // Replace with your Cloudinary API key
  api_secret: 'XbKAbBubyD921ZEiEhpjzGAFcec',  // Replace with your Cloudinary API secret
});

export default cloudinary;
